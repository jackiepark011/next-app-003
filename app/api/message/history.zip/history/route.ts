import { NextResponse } from 'next/server';
import { AligoClient } from '@/lib/api/aligo-client';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const page = Number(searchParams.get('page')) || 1;
    const pageSize = Number(searchParams.get('page_size')) || 30;
    const startDate = searchParams.get('start_date') || undefined;
    const limitDay = searchParams.get('limit_day') || undefined;

    const apiClient = new AligoClient();
    const result = await apiClient.getHistory({
      page,
      page_size: pageSize,
      start_date: startDate,
      limit_day: limitDay,
    });

    // 응답 데이터가 없는 경우 빈 배열 반환
    if (!result.list) {
      return NextResponse.json({
        list: [],
        total_count: 0,
        page,
        page_size: pageSize,
      });
    }

    return NextResponse.json(result);
  } catch (error) {
    console.error('메시지 내역 조회 실패:', error);
    return NextResponse.json(
      { error: '메시지 내역 조회에 실패했습니다.' },
      { status: 500 }
    );
  }
} 