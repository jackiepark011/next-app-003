import { NextResponse } from 'next/server';
import { AligoClient } from '@/lib/api/aligo-client';

export async function GET(
  request: Request,
  { params }: { params: { mid: string } }
) {
  try {
    if (!process.env.NEXT_PUBLIC_ALIGO_API_KEY || !process.env.NEXT_PUBLIC_ALIGO_USER_ID) {
      return NextResponse.json(
        { 
          result_code: -1,
          message: 'API 설정이 완료되지 않았습니다. 관리자에게 문의해주세요.' 
        },
        { status: 400 }
      );
    }

    const apiClient = new AligoClient();
    const result = await apiClient.getMessageDetail(params.mid);

    console.log('상세 조회 API 응답:', result);

    if (!result.list || result.list.length === 0) {
      return NextResponse.json({
        list: [],
        result_code: 1,
        message: '조회된 데이터가 없습니다.'
      });
    }

    // 데이터 가공
    const processedList = result.list.map((item: any) => ({
      ...item,
      receiver: item.receiver || '-',
      sms_state: item.sms_state || '-',
      mdid: item.mdid || '-',
      send_date: item.send_date || '-',
      reserve_date: item.reserve_date || '-',
      reg_date: item.reg_date || '-'
    }));

    return NextResponse.json({
      ...result,
      list: processedList
    });
  } catch (error) {
    console.error('메시지 상세 조회 실패:', error);
    return NextResponse.json(
      { error: '메시지 상세 조회에 실패했습니다.' },
      { status: 500 }
    );
  }
} 